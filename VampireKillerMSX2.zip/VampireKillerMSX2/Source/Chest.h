#pragma once
#include "Enemies.h"
#include "TileMap.h"
// Igual implementado que ZOMBIE

#define CHEST_SPEED_X       2
#define CHEST_SPEED_Y       2
#define CHEST_JUMP_FORCE    3
#define CHEST_ANIM_DELAY    (3*ANIM_DELAY)
#define CHEST_FRAME_SIZE    16

enum class ChestState { IDLE };
enum class ChestAnim {
    IDLE,
    NUM_ANIMATIONS
};

struct ChestStep {
    Point speed;
    int frames;
    int anim;
};

class Chest : public Enemy {
public:
    Chest(const Point& p, int width, int height, int frame_width, int frame_height);
    ~Chest();

    AppStatus Initialise(Look look, const AABB& area) override;
    bool Update(const AABB& box) override;


private:
    void InitPattern();
    void UpdateLook(int anim_id);
    ChestState state;
    int current_step;
    int current_frames;
    std::vector<ChestStep> pattern;

    float base_y;

    Point dir;

    TileMap* map;
};