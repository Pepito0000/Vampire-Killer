#include "Scene.h"
#include <stdio.h>
#include "Globals.h"
#include "LevelBackground.h"
#include "Enemies.h"
#include "Player.h" 
#include "Object.h"
#include "Scene.h"
#include "Game.h"

Scene::Scene() : currentStage(1), fireGenerated(false), firesDestroyed(0), candleDestroyed(0), candleGenerated(0), candlesDestroyedInLevel4(0), candlesDestroyedInLevel5(0), chestGenerated(false), destroyedFires(0)
{
	player = nullptr;
	level = nullptr;
	background = nullptr;
	enemies = nullptr;
	candle = nullptr;
	font = nullptr;

	camera.target = { 0, 0 }; 
	camera.offset = { 0, 0 }; 
	camera.rotation = 0.0f; 
	camera.zoom = 1.0f; 

	debug = DebugMode::OFF;
}
Scene::~Scene()
{
	if (player != nullptr)
	{
		player->Release();
		delete player;
		player = nullptr;
	}
	if (level != nullptr)
	{
		level->Release();
		delete level;
		level = nullptr;
	}
	if (candle != nullptr)
	{
		delete candle;
		candle = nullptr;
	}
	if (font != nullptr)
	{
		delete font;
		font = nullptr;
	}
	if (background != nullptr)
	{
		background->Release();
		delete background;
		background = nullptr;
	}
	for (Entity* obj : objects)
	{
		delete obj;
	}
	objects.clear();
	if (enemies != nullptr)
	{
		enemies->Release();
		delete enemies;
		enemies = nullptr;
	}
}
AppStatus Scene::Init()
{
	// Create player
	player = new Player({ 0, LEVEL_HEIGHT * TILE_SIZE - TILE_SIZE }, State::IDLE, Look::RIGHT);
	if (player == nullptr)
	{
		LOG("Failed to allocate memory for Player");
		return AppStatus::ERROR;
	}
	// Initialise player
	if (player->Initialise() != AppStatus::OK)
	{
		LOG("Failed to initialise Player");
		return AppStatus::ERROR;
	}
	// Initialise font
	font = new Text();
	if (font == nullptr) 
	{
		LOG("Failed to allocate memory for font 1");
		return AppStatus::ERROR;
	}
	if (font->Initialise(Resource::IMG_FONT, "images/CustomFont/Numbers.png", ' ', 8) != AppStatus::OK)  
	{
		LOG("Failed to initialise Level");
		return AppStatus::ERROR;
	}
	if (font->Initialise(Resource::IMG_FONT, "images/CustomFont/Numbers.png", ' ', 8) != AppStatus::OK)  
	{
		LOG("Failed to initialise Level");
		return AppStatus::ERROR;
	}
	// Create enemy manager
	enemies = new EnemyManager();
	if (enemies == nullptr)
	{
		LOG("Failed to allocate memory for Enemy Manager");
		return AppStatus::ERROR;
	}
	// Initialise enemy manager
	if (enemies->Initialise() != AppStatus::OK)
	{
		LOG("Failed to initialise Enemy Manager");
		return AppStatus::ERROR;
	}

	// Create level
	level = new TileMap();
	if (level == nullptr)
	{
		LOG("Failed to allocate memory for Level");
		return AppStatus::ERROR;
	}

	// Create background
	background = new CargarBackground();
	if (background == nullptr)
	{
		LOG("Failed to allocate memory for background");
		return AppStatus::ERROR;
	}
	// Initialise level
	if (level->Initialise() != AppStatus::OK)
	{
		LOG("Failed to initialise Level");
		return AppStatus::ERROR;
	}

	// Load level
	if (LoadLevel(1) != AppStatus::OK)
	{
		LOG("Failed to load Level 1");
		return AppStatus::ERROR;
	}
	// Assign the tile map reference to the player to check collisions while navigating
	player->SetTileMap(level);

	
	return AppStatus::OK;
}
void Scene::ClearLevel()
{
	for (Object* obj : objects)
	{
		delete obj;
	}
	objects.clear();
	enemies->Release();
} 
AppStatus Scene::LoadLevel(int stage)
{
	int size;
	int x, y, i;
	Tile tile;
	Point pos;
	int* map = nullptr;
	Object* obj;
	AABB hitbox, area; 

	int candleCount = 0;
	chestGenerated = false; 

	ClearLevel();

	size = LEVEL_WIDTH * LEVEL_HEIGHT;

	if (stage == 1)
	{
		currentStage = 1;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 200, 0, 0, 0, 0, 0, 0, 0, 200, 0, 0, 0, // 301 zombie
				4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4

		};
		
	}
	else if (stage == 2)
	{
		currentStage = 2;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 200, 0, 0, 0, 0, 0, 0, 0, 200, 0, 0, 0,
				4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4
		};
	}
	else if (stage == 3)
	{
		currentStage = 3;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4
		};
	}
	else if (stage == 4)
	{
		currentStage = 4;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				0, 0, 0, 0, 0, 0, 0, 205, 0, 0, 0, 205, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 301,
				1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2
		};
	}
	else if (stage == 5)
	{
		currentStage = 5;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 3, 1, 2, 1, 2,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 10, 3, 1, 2, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 205, 0, 0, 0, 0, // 205 Es el candelabro
				0, 0, 0, 205, 0, 0, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 301,
				1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2
		};
	}
	else if (stage == 6)
	{
		currentStage = 6;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				1, 2, 1, 2, 1, 2, 3, 6, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0,
				0, 0, 1, 2, 1, 2, 0, 3, 1, 2, 1, 2, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 35, 0, 0, 0, 35, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2
		};
	}
	else if (stage == 7)
	{
		currentStage = 7;
		map = new int[size] {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				-1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 3,
				0, 0, 0, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0,
				1, 2, 1, 2, 3, 6, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 7, 0, 0, 0, 0,
				0, 0, 0, 0, 1, 2, 1, 2, 1, 2, 1, 2, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 1, 2, 1, 2, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 45, 0, 12, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0,
				1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2
		};
	}
	else
	{
		//Error level doesn't exist or incorrect level number
		LOG("Failed to load level, stage %d doesn't exist", stage);
		return AppStatus::ERROR;
	}

	auto isObjectCollected = [this](ObjectType type) {
		return std::find(collectedObjects.begin(), collectedObjects.end(), type) != collectedObjects.end();
	};

	i = 0;
	for (y = 0; y < LEVEL_HEIGHT; ++y) {
		for (x = 0; x < LEVEL_WIDTH; ++x) {
			tile = (Tile)map[i];
			if (tile == Tile::EMPTY) {
				map[i] = 0;
			}
			else if (tile == Tile::PLAYER) {
				pos.x = x * TILE_SIZE;
				pos.y = y * TILE_SIZE + TILE_SIZE - 1;
				player->SetPos(pos);
				map[i] = 0;
			}
			else if (tile == Tile::GOLDEN_KEY) {
				if (!isObjectCollected(ObjectType::GOLDEN_KEY)) {
					pos.x = x * TILE_SIZE;
					pos.y = y * TILE_SIZE + TILE_SIZE - 1;
					obj = new Object(pos, ObjectType::GOLDEN_KEY);
					objects.push_back(obj);
				}
				map[i] = 0;
			}
			else if (tile == Tile::SILVER_KEY) {
				if (!isObjectCollected(ObjectType::SILVER_KEY)) {
					pos.x = x * TILE_SIZE;
					pos.y = y * TILE_SIZE + TILE_SIZE - 1;
					obj = new Object(pos, ObjectType::SILVER_KEY);
					objects.push_back(obj);
				}
				map[i] = 0;
			}
			else if (tile == Tile::BLUE_RING) {
				if (!isObjectCollected(ObjectType::BLUE_RING)) {
					pos.x = x * TILE_SIZE;
					pos.y = y * TILE_SIZE + TILE_SIZE - 1;
					obj = new Object(pos, ObjectType::BLUE_RING);
					objects.push_back(obj);
				}
				map[i] = 0;
			}
			else if (tile == Tile::ZOMBIE) {
				pos.x = x * TILE_SIZE;
				pos.y = y * TILE_SIZE + TILE_SIZE - 1;
				hitbox = enemies->GetEnemyHitBox(pos, EnemyType::ZOMBIE);
				area = level->GetSweptAreaX(hitbox);
				enemies->Add(pos, EnemyType::ZOMBIE, area, Look::RIGHT);
				map[i] = 0;
			}
			else if (tile == Tile::FIRE) {
				Vector2 firePos = { static_cast<float>(x * TILE_SIZE), static_cast<float>(y * TILE_SIZE + TILE_SIZE - 1) };
				if (!isFireDestroyed(firePos, currentStage)) {
					pos.x = x * TILE_SIZE;
					pos.y = y * TILE_SIZE + TILE_SIZE - 1;
					hitbox = enemies->GetEnemyHitBox(pos, EnemyType::FIRE);
					area = level->GetSweptAreaX(hitbox);
					enemies->Add(pos, EnemyType::FIRE, area, Look::RIGHT);
				}
				map[i] = 0;
			}
			else if (tile == Tile::CANDLE) {
				Vector2 candlePos = { static_cast<float>(x * TILE_SIZE), static_cast<float>(y * TILE_SIZE + TILE_SIZE - 1) };
				if (!isCandleDestroyed(candlePos, currentStage)) {
					// Limitar la cantidad de candelabros generados
					if ((currentStage == 4 && candleCount < 2) || (currentStage == 5 && candleCount < 3)) {
						pos.x = x * TILE_SIZE;
						pos.y = y * TILE_SIZE + TILE_SIZE - 1;
						hitbox = enemies->GetEnemyHitBox(pos, EnemyType::CANDLE);
						area = level->GetSweptAreaX(hitbox);
						enemies->Add(pos, EnemyType::CANDLE, area, Look::RIGHT);
						candleCount++;
					}
				}
				map[i] = 0;
			}

			else if (tile == Tile::CHEST) {
				Vector2 chestPos = { static_cast<float>(x * TILE_SIZE), static_cast<float>(y * TILE_SIZE + TILE_SIZE - 1) };
				if (!isChestDestroyed(chestPos, currentStage)) {
					pos.x = x * TILE_SIZE;
					pos.y = y * TILE_SIZE + TILE_SIZE - 1;
					hitbox = enemies->GetEnemyHitBox(pos, EnemyType::CHEST);
					area = level->GetSweptAreaX(hitbox);
					enemies->Add(pos, EnemyType::CHEST, area, Look::RIGHT);
					chestGenerated = true;
				}
				map[i] = 0;
			}

			else {
				LOG("Internal error loading scene: invalid entity or object tile id");
			}
			++i;
		}
	}

	level->Load(map, LEVEL_WIDTH, LEVEL_HEIGHT);
	delete[] map;

	return AppStatus::OK;
}
bool Scene::isFireDestroyed(const Vector2& pos, int level) const {
	for (size_t i = 0; i < destroyedFirePositions.size(); ++i) {
		if (destroyedFirePositions[i].x == pos.x && destroyedFirePositions[i].y == pos.y && destroyedFireLevels[i] == level) {
			return true;
		}
	}
	return false;
}
bool Scene::isCandleDestroyed(const Vector2& pos, int level) const {
	for (size_t i = 0; i < destroyedCandlePositions.size(); ++i) {
		if (destroyedCandlePositions[i].x == pos.x && destroyedCandlePositions[i].y == pos.y && destroyedCandleLevels[i] == level) {
			return true;
		}
	}
	return false;
}
bool Scene::isChestDestroyed(const Vector2& pos, int level) const {
	for (size_t i = 0; i < destroyedChestPositions.size(); ++i) {
		if (destroyedChestPositions[i].x == pos.x && destroyedChestPositions[i].y == pos.y && destroyedChestLevels[i] == level) {
			return true;
		}
	}
	return false;
}
void Scene::GenerateFire() {
	if ((currentStage == 1 || currentStage == 2 || currentStage == 3) && !fireGenerated) {
		Point pos1, pos2;
		AABB area;

		if (currentStage == 1) {
			pos1.x = (LEVEL_WIDTH / 2) * TILE_SIZE - 64;
			pos1.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
			pos2.x = (LEVEL_WIDTH / 2) * TILE_SIZE  + 64; 
			pos2.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95; 
		}
		else if (currentStage == 2) {
			pos1.x = (LEVEL_WIDTH / 2) * TILE_SIZE - 64;
			pos1.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
			pos2.x = (LEVEL_WIDTH / 2) * TILE_SIZE  + 64; 
			pos2.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95; 
		}
		else if (currentStage == 3) {
			pos1.x = (LEVEL_WIDTH / 2) * TILE_SIZE - 64;
			pos1.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
		}

		enemies->Add(pos1, EnemyType::FIRE, area, Look::LEFT);
		enemies->Add(pos2, EnemyType::FIRE, area, Look::RIGHT);
		fireGenerated = true;
	}
}
void Scene::GenerateCandle() {
	if ((currentStage == 4 || currentStage == 5) && !candleGenerated) {
		Point pos1, pos2;
		AABB area;

		if (currentStage == 4) {
			pos1.x = (LEVEL_WIDTH / 2) * TILE_SIZE - 64;
			pos1.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
			pos2.x = (LEVEL_WIDTH / 2) * TILE_SIZE + 64;
			pos2.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
		}
		else if (currentStage == 5) {
			pos1.x = (LEVEL_WIDTH / 2) * TILE_SIZE - 64;
			pos1.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
			pos2.x = (LEVEL_WIDTH / 2) * TILE_SIZE + 64;
			pos2.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;
		}

		/*enemies->Add(pos1, EnemyType::CANDLE, area, Look::LEFT);
		enemies->Add(pos2, EnemyType::CANDLE, area, Look::RIGHT);*/
		candleGenerated = true;
	}
}

void Scene::GenerateChest() {
	if ((currentStage == 7) && !chestGenerated) {
		Point pos;
		pos.x = (LEVEL_WIDTH / 2) * TILE_SIZE - 48;
		pos.y = (LEVEL_HEIGHT / 2) * TILE_SIZE + 95;

		AABB hitbox = enemies->GetEnemyHitBox(pos, EnemyType::CHEST); 
		AABB area = level->GetSweptAreaX(hitbox);
		enemies->Add(pos, EnemyType::CHEST, area, Look::RIGHT);
		chestGenerated = true;
	}
}

void Scene::Update()
{
	Point p1, p2;
	AABB hitbox, area;

	//Switch between the different debug modes: off, on (sprites & hitboxes), on (hitboxes) 
	if (IsKeyPressed(KEY_F1))
	{
		debug = (DebugMode)(((int)debug + 1) % (int)DebugMode::SIZE);
	}
	//Debug levels instantly
	if (IsKeyPressed(KEY_ONE))            LoadLevel(1);
	else if (IsKeyPressed(KEY_TWO))        LoadLevel(2);
	else if (IsKeyPressed(KEY_THREE))    LoadLevel(3);
	else if (IsKeyPressed(KEY_FOUR))    LoadLevel(4);
	else if (IsKeyPressed(KEY_FIVE))    LoadLevel(5);
	else if (IsKeyPressed(KEY_SIX))        LoadLevel(6);
	else if (IsKeyPressed(KEY_SEVEN))    LoadLevel(7);
	else if (IsKeyPressed(KEY_D))        player->getDamage(Look::RIGHT); 

	level->Update();
	player->Update();
	GenerateZombies();
	GenerateFire(); 
	GenerateCandle();
	GenerateChest(); 
	UpdateBackground(currentStage);

	CheckCollisions();

	hitbox = player->GetHitbox();
	enemies->Update(hitbox);
}
void Scene::GenerateZombies()
{
	// Verificar si el nivel actual es 4 o 5 antes de continuar
	if (currentStage == 4 || currentStage == 5)
	{
		static int contadorDeFrames = 0;
		contadorDeFrames++;

		if (contadorDeFrames >= 120)
		{
			contadorDeFrames = 0;
			Point posicionZombie;
			posicionZombie.y = 191; 

			AABB areaZombie; 
			if (player->GetPlayerPosX() <= WINDOW_WIDTH / 2)
			{
				posicionZombie.x = (LEVEL_WIDTH - 1) * TILE_SIZE;
				enemies->Add(posicionZombie, EnemyType::ZOMBIE, areaZombie, Look::RIGHT);
			}
			else
			{
				posicionZombie.x = 0;
				enemies->Add(posicionZombie, EnemyType::ZOMBIE, areaZombie, Look::LEFT);
			}
		}
	}
	else
	{
		return; // No generar zombies si no estamos en el nivel 4 o 5
	}
}

void Scene::Render() {
	BeginMode2D(camera);

	background->RenderBackground(currentStage);
	level->Render();
	if (debug == DebugMode::OFF || debug == DebugMode::SPRITES_AND_HITBOXES) {
		RenderObjects();
		enemies->Draw();
		player->Draw();
		
	}
	if (debug == DebugMode::SPRITES_AND_HITBOXES || debug == DebugMode::ONLY_HITBOXES) {
		RenderObjectsDebug(YELLOW);
		player->DrawDebug(GREEN);
		enemies->DrawDebug();
	}

	EndMode2D();

	RenderGUI();
}

void Scene::Release()
{
	background->Release();
	level->Release();
	player->Release();
	ClearLevel();
}
			
void Scene::CheckCollisions() {
	AABB player_box, obj_box, enemy_box;

	player_box = player->GetHitbox();
	auto it = objects.begin();
	while (it != objects.end()) {
		obj_box = (*it)->GetHitbox();

		if (player_box.TestAABB(obj_box)) {
			// Aumentar la vida del jugador seg�n el tipo de objeto recogido
			if ((*it)->type == ObjectType::SMALL_HEART) {
				player->IncreaseLife(1);
			}
			else if ((*it)->type == ObjectType::BIG_HEART) {
				player->IncreaseLife(5);
			}

			// "Recoge" el �tem agreg�ndolo a la lista de objetos recogidos
			player->items.push_back((*it)->type);
			collectedObjects.push_back((*it)->type); // Agregar el objeto a la lista de objetos recogidos

			// Elimina el objeto
			delete* it;
			it = objects.erase(it);
		}
		else {
			++it;
		}
	}

	// Check collisions with enemies
	auto& enemiesList = enemies->GetEnemies();
	enemiesList.erase(std::remove_if(enemiesList.begin(), enemiesList.end(),
		[this, &player_box](Enemy* enemy) {
			bool isFire = dynamic_cast<Fire*>(enemy) != nullptr;
			bool isCandle = dynamic_cast<Candle*>(enemy) != nullptr;
			bool isChest = dynamic_cast<Chest*>(enemy) != nullptr;
			AABB enemy_box = enemy->GetHitbox();

			// Check collision with player hitbox
			if (player_box.TestAABB(enemy_box)) {
				// Excluir fuegos, candelabros y cofres
				if (!isFire && !isCandle && !isChest) {
					Look damageDirection = player->GetPlayerPosX() > enemy->GetPos().x ? Look::LEFT : Look::RIGHT;
					player->getDamage(damageDirection);
				}
				return false; // Don't remove enemy on collision with player
			}

			// Check collision with player attack hitbox
			AABB attack_hitbox = player->GetAttackHitbox();
			if (attack_hitbox.TestAABB(enemy_box)) {
				Point enemy_pos = enemy->GetPos();
				ObjectType dropType;

				if (isFire) {
					// A�adir a la lista de fuegos destruidos
					destroyedFirePositions.push_back({ static_cast<float>(enemy_pos.x), static_cast<float>(enemy_pos.y) });
					destroyedFireLevels.push_back(currentStage);

					dropType = (currentStage == 1) ? ObjectType::SMALL_HEART : ObjectType::BIG_HEART;
				}
				else if (isCandle) {
					// A�adir a la lista de candelabros destruidos
					destroyedCandlePositions.push_back({ static_cast<float>(enemy_pos.x), static_cast<float>(enemy_pos.y) });
					destroyedCandleLevels.push_back(currentStage);

					if (currentStage == 4) {
						if (candlesDestroyedInLevel4 == 0) {
							dropType = ObjectType::BLUE_RING;
						}
						else {
							dropType = ObjectType::SMALL_HEART;
						}
						candlesDestroyedInLevel4++;
					}
					else if (currentStage == 5) {
						if (candlesDestroyedInLevel5 == 0 || candlesDestroyedInLevel5 == 1) {
							dropType = ObjectType::SMALL_HEART;
						}
						else {
							dropType = ObjectType::BLUE_RING;
						}
						candlesDestroyedInLevel5++;
					}
					else {
						dropType = ObjectType::SMALL_HEART;
					}
				}
				else if (isChest) {
					// A�adir a la lista de cofres destruidos
					destroyedChestPositions.push_back({ static_cast<float>(enemy_pos.x), static_cast<float>(enemy_pos.y) });
					destroyedChestLevels.push_back(currentStage);

					dropType = ObjectType::BLUE_RING;
				}

				// Crear y agregar el objeto soltado si es un fuego, candelabro o cofre
				if (isFire || isCandle || isChest) {
					Object* droppedItem = new Object(enemy_pos, dropType);
					objects.push_back(droppedItem);
				}

				// Eliminar al enemigo
				player->IncrScore(100);
				delete enemy;
				return true; // Remove enemy
			}

			return false; // Don't remove enemy if no attack hit
		}), enemiesList.end());
}


void Scene::RenderObjects() const
{
	for (Object* obj : objects)
	{
		obj->Draw();
	}
}
void Scene::RenderObjectsDebug(const Color& col) const
{
	for (Object* obj : objects)
	{
		obj->DrawDebug(col);
	}
}
void Scene::RenderGUI() const
{
	// Obtiene los �tems que el jugador ha recogido
	const std::vector<ObjectType>& items = player->GetItems();

	// Definici�n de ITEM_SPACING (para poder configurar bien y ajustar el codigo a separarlos mndas o menos)
	const float ITEM_SPACING = 8.0f; 
	const float ITEM_SIZE = 32.0f;   

	// Posiciones iniciales para las columnas de �tems
	float keyStartX = 148.0f;
	float itemStartX = 182.0f;
	float yPos = 12.0f; // Altura fija para todos los �tems

	// �ndices para las posiciones de los �tems
	int keyIndex = 0;
	int itemIndex = 0;
	int blueRingCount = 0;

	// Dibuja las llaves en la parte izquierda de la interfaz
	for (const auto& item : items)
	{
		if (item == ObjectType::GOLDEN_KEY || item == ObjectType::SILVER_KEY)
		{
			Vector2 pos = { keyStartX + keyIndex * (ITEM_SIZE + ITEM_SPACING), yPos };
			player->DrawItem(item, pos);
			++keyIndex;
		}
	}

	// Dibuja los dem�s �tems en la parte derecha de la interfaz
	for (const auto& item : items)
	{
		Vector2 pos;
		if (item == ObjectType::BLUE_RING) {
			if (blueRingCount == 0) {
				pos = { 183.0f, yPos };
			}
			else if (blueRingCount == 1) {
				pos = { 200.0f, yPos };
			}
			else if (blueRingCount == 2) {
				pos = { 217.0f, yPos };
			}
			++blueRingCount;
		}
		else {
			pos = { itemStartX + itemIndex * (ITEM_SIZE + ITEM_SPACING), yPos };
			++itemIndex;
		}
		player->DrawItem(item, pos);

}

	// UI
	static int frame;
	frame++;
	frame %= 1000;

	//UI stages
	if (currentStage == 1) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 0));  
	}
	if (currentStage == 2) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 0));
	}
	if (currentStage == 3) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 0));
	}
	if (currentStage == 4) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 1));
	}
	if (currentStage == 5) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 1));
	}
	if (currentStage == 6) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 1));
	}
	if (currentStage == 7) {
		font->Draw(155, 1, TextFormat("%d%d", 0, 1));
	}
	// UI score (TEXTO)
	font->Draw(192, 1, TextFormat("%d", player->GetCorazones() + 3));    
	font->Draw(228, 1, TextFormat("%d%d", 0, 2));
	font->Draw(58, 1, TextFormat("%d", player->GetScore()));
	/*font->Draw(10, 20, TextFormat("FRAME:%d", frame), WHITE);		*/
}

void Scene::UpdateBackground(int s)
{
	int x = player->GetPlayerPosX();
	int y = player->GetPlayerPosY();
	switch (currentStage)
	{
	case 1:
		if (x < 0){
			player->SetPos({ 0,y });
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= LEVEL_WIDTH * TILE_SIZE){
			player->SetPos({ 0, y });
			LoadLevel(2);
			break;
		}
	case 2:
		if (x < 0){
			player->SetPos({ (LEVEL_WIDTH * TILE_SIZE) - 15 - PLAYER_PHYSICAL_WIDTH, y });
			LoadLevel(1);
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= LEVEL_WIDTH * TILE_SIZE){
			player->SetPos({ 0, y });
			LoadLevel(3);
			break;
		}
	case 3:
		if (x < 0){
			player->SetPos({ (LEVEL_WIDTH * TILE_SIZE) - 15 - PLAYER_PHYSICAL_WIDTH, y });
			LoadLevel(2);
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= LEVEL_WIDTH * TILE_SIZE){
			player->SetPos({ 0, y });
			LoadLevel(4);
			break;
		}
	case 4:
		if (x < 0){
			player->SetPos({ (LEVEL_WIDTH * TILE_SIZE) - 15 - PLAYER_PHYSICAL_WIDTH, y });
			LoadLevel(3);
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= LEVEL_WIDTH * TILE_SIZE){
			player->SetPos({ 0, y });
			LoadLevel(5);
			break;
		}
	case 5:
		if (x < 0){
			player->SetPos({ (LEVEL_WIDTH * TILE_SIZE) - 15 - PLAYER_PHYSICAL_WIDTH, y });
			LoadLevel(4);
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= LEVEL_WIDTH * TILE_SIZE){
			player->SetPos({ 0, y });
			LoadLevel(7);
			break;
		}
	case 6:
		if (x < 0){
			player->SetPos({ (LEVEL_WIDTH * TILE_SIZE) - 15 - PLAYER_PHYSICAL_WIDTH, y });
			LoadLevel(5);
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= LEVEL_WIDTH * TILE_SIZE){
			player->SetPos({ 0, y });
			LoadLevel(7);		
			break;
		}
	case 7:
		if (x < 0){
			player->SetPos({ (LEVEL_WIDTH * TILE_SIZE) - 15 - PLAYER_PHYSICAL_WIDTH, y });
			LoadLevel(5);
			break;
		}
		else if (x + PLAYER_PHYSICAL_WIDTH >= 80){
			exit = true;
			break;
		}
	}
}
