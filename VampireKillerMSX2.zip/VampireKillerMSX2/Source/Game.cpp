#include "Game.h"
#include "Globals.h"
#include "ResourceManager.h"
#include <stdio.h>
#include "Scene.h"
#include "Player.h"

Game::Game()
{
    state = GameState::MAIN_MENU;
    scene = nullptr;
    img_menu = nullptr;

    target = {};
    src = {};
    dst = {};
}
Game::~Game()
{
    if (scene != nullptr)
    {
        scene->Release();
        delete scene;
        scene = nullptr;
    }
}
AppStatus Game::Initialise(float scale)
{
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    InitWindow(screenWidth, screenHeight, "Vampire Killer");

  
    ToggleFullscreen(); 
    InitAudioDevice();

    // Render texture initialization, used to hold the rendering result so we can easily resize it
    target = LoadRenderTexture(WINDOW_WIDTH, WINDOW_HEIGHT);
    if (target.id == 0)
    {
        LOG("Failed to create render texture");
        return AppStatus::ERROR;
    }
    SetTextureFilter(target.texture, TEXTURE_FILTER_POINT);

    // Source rectangle is the size of the original game
    src = { 0, 0, (float)WINDOW_WIDTH, -(float)WINDOW_HEIGHT };

    // Load resources
    if (LoadResources() != AppStatus::OK)
    {
        LOG("Failed to load resources");
        return AppStatus::ERROR;
    }
    //Sonidos
    musicArray[0] = LoadMusicStream("Audio/Prologue.ogg");
    musicArray[1] = LoadMusicStream("Audio/Vampire Killer.ogg");
    musicArray[2] = LoadMusicStream("Audio/Ending.ogg");
    intro = LoadTexture("images/Sprites/Intro.png");

    // Cargar texturas para introduccion (animacion)
    castillo = LoadTexture("images/Sprites/FondoCastillo.png");
    creditos_finales = LoadTexture("images/Sprites/Ending.png");
    /*creditos_finales = LoadTexture("images/Ending.png");*/
    personajeFrontal = LoadTexture("images/Sprites/PersonajePrincipal.png");
    personajeEspaldas = LoadTexture("images/Sprites/PersonajePrincipal.png");
    nube = LoadTexture("images/Sprites/nube.png");
    murcielago = LoadTexture("images/Sprites/murciegalo.png");
    murcielago2 = LoadTexture("images/Sprites/murciegalo.png");
    
    // Set the target frame rate for the application
    SetTargetFPS(60);
    // Disable the escape key to quit functionality
    SetExitKey(0);

    return AppStatus::OK;
}
AppStatus Game::LoadResources()
{
    return AppStatus::OK;
}
AppStatus Game::BeginPlay()
{
    scene = new Scene();
    if (scene == nullptr)
    {
        LOG("Failed to allocate memory for Scene");
        return AppStatus::ERROR;
    }
    if (scene->Init() != AppStatus::OK)
    {
        LOG("Failed to initialise Scene");
        return AppStatus::ERROR;
    }

    return AppStatus::OK;
}
void Game::FinishPlay()
{
    scene->Release();
    delete scene;
    scene = nullptr;
}
void Game::SetState(GameState newState) {
    state = newState;
}
AppStatus Game::Update()
{
    //Check if user attempts to close the window, either by clicking the close button or by pressing Alt+F4
    if (WindowShouldClose()) return AppStatus::QUIT;

    BeginTextureMode(target);

    switch (state)
    {
    case GameState::MAIN_MENU:
    {
        if (IsKeyPressed(KEY_ESCAPE)) return AppStatus::QUIT;
        if (BeginPlay() != AppStatus::OK)   return AppStatus::ERROR;
        if (IsKeyPressed(KEY_SPACE))
        {
            if (BeginPlay() != AppStatus::OK) return AppStatus::ERROR;

            state = GameState::INTRO;
        }
        break;
    }
    case GameState::RESET: {
        state = GameState::MAIN_MENU;  
    }
    case GameState::INTRO:
    {
        posicionNube.x -= 0.1;
        posMurcielago.x -= 0.15;
        pos2Murcielago.x += 0.15;
        pos2Murcielago.y -= 0.08;

        if (IsKeyPressed(KEY_ESCAPE)) return AppStatus::QUIT;
        contadorFrames++;
        if (contadorFrames >= (60 / velFrames))
        {
            contadorFrames = 0;
            if (!introPlayed) {
                currentFrameIntro++;
                if (currentFrameIntro >= FramesIntro) {
                    velFrames = 10;
                    currentFrameIntro = FramesIntro - 1;
                    if (IsKeyDown(KEY_SPACE)) introPlayed = true;
                }
            }
            else if (!animation2Played) {
                currentFrameAnimacion2++;
                if (currentFrameAnimacion2 >= FramesAnimacion2) {
                    velFrames = 10;
                    currentFrameAnimacion2 = FramesAnimacion2 - 1;
                }
            }
        }
        if (!music1Played && introPlayed) {
            PlayMusicStream(musicArray[0]);
            UpdateMusicStream(musicArray[0]);
            if (GetMusicTimePlayed(musicArray[0]) > 6.0) {
                StopMusicStream(musicArray[0]);
                music1Played = true;
                ResetAnimations();
                state = GameState::PLAYING;
            }
        }
        if (posicionPersonaje.x > WINDOW_WIDTH / 2) {
            posicionPersonaje.x -= 0.5f;
        }
        else if (!personajeQuieto) {
            personajeQuieto = true;
            personajeEstaFrontal = false;
        }
        if (!personajeQuieto) {
            contadorFrames++;
            if (contadorFrames >= (60 / velFrames)) {
                contadorFrames = 0;
                currentFramePersonajeFrontal++;
                if (currentFramePersonajeFrontal >= FramesPersonajeFrontal) {
                    velFrames = 1;
                    currentFramePersonajeFrontal = 0;
                }
            }
        }
        if (!animacionMurcielagoPlayed) {
            contadorFrames2++;
            if (contadorFrames2 >= (60 / velFrames2)) {
                contadorFrames2 = 0;
                currentFrameMurcielago++;
                currentFrameMurcielago2++;
                if (currentFrameMurcielago >= totalFramesMurcielago) {
                    velFrames2 = 3;
                    currentFrameMurcielago = 0;
                }
                if (currentFrameMurcielago2 >= totalFramesMurcielago2) {
                    velFrames2 = 3;
                    currentFrameMurcielago2 = 0;
                }
            }
        }
        contadorFrames2++;
        if (contadorFrames2 >= (60 / velFrames2)) {
            contadorFrames2 = 0;
            currentFrameMurcielago++;
            currentFrameMurcielago2++;
            if (currentFrameMurcielago >= totalFramesMurcielago) {
                velFrames2 = 5;
                currentFrameMurcielago = 0;
            }
            if (currentFrameMurcielago2 >= totalFramesMurcielago2) {
                velFrames2 = 5;
                currentFrameMurcielago2 = 0;
            }
        }
        break;
    }
    case GameState::PLAYING:
    {
        if (!music2Played && state == GameState::PLAYING) {
            PlayMusicStream(musicArray[1]);
        }
        UpdateMusicStream(musicArray[1]);
        if (IsKeyPressed(KEY_ESCAPE)) {
            FinishPlay();
            StopMusicStream(musicArray[1]);
            music2Played = true;
            state = GameState::MAIN_MENU;
            ResetAnimations();
        }
        else if (IsKeyPressed(KEY_F4)) {
            state = GameState::CREDITS;
            StopMusicStream(musicArray[1]);
            music2Played = true;
        }
        else if (scene->currentStage == 7 && scene->exit == true)  state = GameState::CREDITS;
        else {
            scene->Update();
        }
        break;
    }
    case GameState::CREDITS:
        creditPositionY -= CREDIT_SCROLL_SPEED;
        if (!music3Played && state == GameState::CREDITS) {
            PlayMusicStream(musicArray[2]);
        }
        UpdateMusicStream(musicArray[2]);
        if (IsKeyPressed(KEY_ESCAPE)) {
            state = GameState::MAIN_MENU;
            StopMusicStream(musicArray[1]);
            music3Played = true;
            ResetCredits();
        }
        if (creditPositionY + creditos_finales.height < 0) {
            creditsFinished = true;
        }
        if (creditsFinished) {
            state = GameState::MAIN_MENU;
            music3Played = true;
            ResetCredits();
        }
        break;
    }
    return AppStatus::OK;
}

void Game::ResetAnimations()
{
    // Frames
    currentFrameIntro = 0;
    currentFrameAnimacion2 = 0;

    contadorFrames = 0;
    contadorFrames2 = 0;
    velFrames2 = 1;
    velFrames = 1;
    introPlayed = false;
    animation2Played = false;

    //Musica...
    music1Played = false;
    music2Played = false;

    //Personaje
    personajeEstaFrontal = true;
    personajeQuieto = false;
    currentFramePersonajeFrontal = 0;
    currentFramePersonajeEspaldas = 5;

    //Murcielago
    animacionMurcielagoPlayed = false;
    animationbat2Played = false;
    currentFrameMurcielago = 0;
    currentFrameMurcielago2 = 0;

    //Vectores
    posicionPersonaje = { WINDOW_WIDTH - 30, 95 };
    posicionNube = { WINDOW_WIDTH - 52, 100 };
    posMurcielago = { WINDOW_WIDTH / 3 + 30, 70 };
    pos2Murcielago = { WINDOW_WIDTH / 3 - 110, 120 };
}

void Game::ResetCredits() {
    music3Played = false;
    creditsFinished = false;
    creditPositionY = WINDOW_HEIGHT;
}

void Game::Render()
{
    // Draw everything in the render texture, note this will not be rendered on screen, yet
    BeginTextureMode(target);
    ClearBackground(BLACK);

    switch (state)
    {
    case GameState::MAIN_MENU:
    {
        Image imgMenu = LoadImage("images/presentacion.png");
        ImageResize(&imgMenu, WINDOW_WIDTH, WINDOW_HEIGHT);
        Texture2D img_menu = LoadTextureFromImage(imgMenu);
        UnloadImage(imgMenu);
        DrawTexture(img_menu, 0, 0, WHITE);
    }
    break;

    case GameState::INTRO:
        ClearBackground(RAYWHITE);
        if (!introPlayed)
        {
            Rectangle source = { currentFrameIntro * WINDOW_WIDTH, 0, WINDOW_WIDTH, WINDOW_HEIGHT };
            DrawTextureRec(intro, source, Vector2{ 0, 0 }, WHITE);
        }
        else if (!animation2Played)
        {
            Rectangle source = { 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT };
            DrawTextureRec(castillo, source, Vector2{ 0,0 }, WHITE);

            if (personajeEstaFrontal)
            {
                Rectangle sourceCharacter = { currentFramePersonajeFrontal * SPRITE_SIZE, 0, -SPRITE_SIZE, SPRITE_SIZE };
                Rectangle destCharacter = { posicionPersonaje.x + SPRITE_SIZE, posicionPersonaje.y, SPRITE_SIZE, SPRITE_SIZE };
                DrawTexturePro(personajeFrontal, sourceCharacter, destCharacter, Vector2{ destCharacter.width, destCharacter.height - 110 }, 0, WHITE);
            }
            else
            {
                Rectangle sourceCharacter = { currentFramePersonajeEspaldas * SPRITE_SIZE, 0, SPRITE_SIZE, SPRITE_SIZE };
                Rectangle destCharacter = { posicionPersonaje.x, posicionPersonaje.y, SPRITE_SIZE, SPRITE_SIZE };
                DrawTexturePro(personajeEspaldas, sourceCharacter, destCharacter, Vector2{ destCharacter.width - 20, destCharacter.height - 110 }, 0, WHITE);
            }
            Rectangle cloudSource = { 0, 0, CLOUD_SIZE, CLOUD_SIZE };
            Rectangle cloudDest = { posicionNube.x, posicionNube.y, CLOUD_SIZE, CLOUD_SIZE };
            DrawTexturePro(nube, cloudSource, cloudDest, Vector2{ cloudDest.width / 2 - 35, cloudDest.height / 2 + 25 }, 0, WHITE);

            Rectangle batSource1 = { (int)currentFrameMurcielago * SPRITE_SIZE, 0, SPRITE_SIZE, SPRITE_SIZE };
            Rectangle batDest1 = { (int)posMurcielago.x, (int)posMurcielago.y, SPRITE_SIZE, SPRITE_SIZE };
            DrawTexturePro(murcielago, batSource1, batDest1, Vector2{ batDest1.width / 2, batDest1.height / 2 }, 0, WHITE);

            Rectangle batSource2 = { (int)currentFrameMurcielago2 * SPRITE_SIZE, 0, SPRITE_SIZE, SPRITE_SIZE };
            Rectangle batDest2 = { (int)pos2Murcielago.x, (int)pos2Murcielago.y, SPRITE_SIZE, SPRITE_SIZE };
            DrawTexturePro(murcielago2, batSource2, batDest2, Vector2{ batDest2.width / 2, batDest2.height / 2 }, 0, WHITE);
        }
        break;

    case GameState::PLAYING:
        scene->Render();
        break;

    case GameState::CREDITS:
        DrawTexture(creditos_finales, 0, creditPositionY, WHITE);
        break;
    }
    EndTextureMode();

    // Draw render texture to screen, properly scaled
    BeginDrawing();
    ClearBackground(BLACK); // Clear the entire screen to black

    // Calculate the center position for the render target
    float screenWidth = (float)GetScreenWidth();
    float screenHeight = (float)GetScreenHeight();
    float scaleX = screenWidth / WINDOW_WIDTH;
    float scaleY = screenHeight / WINDOW_HEIGHT;
    float scale = (scaleX < scaleY) ? scaleX : scaleY;
    float scaledWidth = WINDOW_WIDTH * scale;
    float scaledHeight = WINDOW_HEIGHT * scale;
    float offsetX = (screenWidth - scaledWidth) / 2;
    float offsetY = (screenHeight - scaledHeight) / 2;

    // Draw the render target texture centered on the screen
    Rectangle dest = { offsetX, offsetY, scaledWidth, scaledHeight };
    DrawTexturePro(target.texture, src, dest, { 0, 0 }, 0.0f, WHITE);

    // Draw black bars (margins) if necessary to maintain aspect ratio
    if (scaleX < scaleY) {
        float barHeight = (screenHeight - scaledHeight) / 2;
        DrawRectangle(0, 0, screenWidth, barHeight, BLACK); // Top bar
        DrawRectangle(0, screenHeight - barHeight, screenWidth, barHeight, BLACK); // Bottom bar
    }
    else {
        float barWidth = (screenWidth - scaledWidth) / 2;
        DrawRectangle(0, 0, barWidth, screenHeight, BLACK); // Left bar
        DrawRectangle(screenWidth - barWidth, 0, barWidth, screenHeight, BLACK); // Right bar
    }

    EndDrawing();
}
void Game::Cleanup()
{
    UnloadTexture(background);
    UnloadTexture(intro);
    UnloadTexture(personajeFrontal);
    UnloadTexture(personajeEspaldas);
    UnloadTexture(nube);
    UnloadTexture(murcielago);
    UnloadTexture(creditos_finales);
    CloseAudioDevice();
    UnloadResources();
    CloseWindow();
    UnloadMusicStream(musicArray[0]);
    UnloadMusicStream(musicArray[1]);
}
void Game::UnloadResources()
{
    ResourceManager& data = ResourceManager::Instance();
    data.ReleaseTexture(Resource::IMG_MENU);

    UnloadRenderTexture(target);
}