#pragma once
#include <raylib.h>
#include "Sprite.h"
#include "Point.h"
#include "AABB.h"
#include "Globals.h"
#include <unordered_map>

enum class Tile {

	// area vacia
	EMPTY = -1,
	//  0: air tile
	AIR = 0,

	// 0 < id < 10: static tiles
	BLOCK_LEFT = 1, BLOCK_RIGHT = 2, BLOCK = 3, GRASS = 4,
	
	STAIRS_LEFT = 6, STAIRS_RIGHT = 7, STAIRS_BOSS = 8,
	STAIRS_LEFT_TOP = 9, STAIRS_RIGHT_TOP = 10, STAIRS_BOSS_TOP = 11,
	CHEST1, 

	// 10 < id < 45: objectos

	WHIP, AXE, KNIFE, BLUE_CROSS, HOURGLASS, HOLY_WATER,
	STAFF, MONEY_WHITE, MONEY_BLUE, BLUE_ORB, BLUE_WATER, BOOTS,
	RED_SHIELD, GOLDEN_SHIELD, BLUE_RING, BLACK_BIBLE, WHITE_BIBLE, WINGS, //Blue ring == 26
	SILVER_CROSS, GOLDEN_CROSS, PARCHMENT,
	FIRE1, FIRE2, // 34 y 35
	CANDLE_BIG, CANDLE_SMALL,// 35, 36
	OBJECT_ANIM1, OBJECT_ANIM2, OBJECT_ANIM3,
	BOSS_ITEM1, BOSS_ITEM2, BOSS_ITEM3, BOSS_ATTACK,
	GOLDEN_KEY, SILVER_KEY,
	SMALL_HEART, BIG_HEART, PLAIN_HEART,

	// id >= 100: entities' initial locations
	PLAYER = 100,
	ZOMBIE = 301,
	FIRE = 200,
	CANDLE = 205,
	CHEST = 250,

	STATIC_FIRST = BLOCK_LEFT,
	STATIC_LAST = CHEST,
	SOLID_FIRST = BLOCK_LEFT,
	SOLID_LAST = CHEST,
	STAIR_FIRST = STAIRS_LEFT,
	STAIR_LAST = STAIRS_BOSS,
	SPECIAL_FIRST = WHIP,
	SPECIAL_LAST = PLAIN_HEART,
	ENTITY_FIRST = PLAYER,
	ENTITY_LAST = PLAYER 
};

class TileMap
{
public:
	TileMap();
	~TileMap();

	AppStatus Initialise(); 
	AppStatus Load(int data[], int w, int h);
	void Update();
	void Render();
	void Release();

	//Test for collisions with walls
	bool TestCollisionWallLeft(const AABB& box) const;
	bool TestCollisionWallRight(const AABB& box) const;

	AABB GetSweptAreaX(const AABB& hitboxbox) const;
	//Test collision with the ground and update 'py' with the maximum y-position to prevent
	//penetration of the grounded tile, that is, the pixel y-position above the grounded tile.
	//Grounded tile = solid tile (blocks) or ladder tops.
	bool TestCollisionGround(const AABB& box, int* py) const;

	//Test if there is a ground tile one pixel below the given box
	bool TestFalling(const AABB& box) const;

	//Test if box is on ladder and update 'px' with the x-center position of the ladder
	//bool TestOnLadder(const AABB& box, int* px) const;

	//Test if box is on ladder top and update 'px' with the x-center position of the ladder
	//bool TestOnLadderTop(const AABB& box, int* px) const;

	bool TestOnLadder(const AABB& box, int* px) const;
	Tile GetTileIndex(int x, int y) const;
	bool IsTileLadder(Tile tile) const;
	bool TestOnLadderTop(const AABB& box, int* px) const;


private:



	void InitTileDictionary();
	bool IsTileSolid(Tile tile) const;
	//bool IsTileLadderTop(Tile tile) const;
	bool CollisionX(const Point& p, int distance) const;
	bool CollisionY(const Point& p, int distance) const;
	//int GetLadderCenterPos(int pixel_x, int pixel_y) const;
	bool IsTileLadderTop(Tile tile) const;


	//Tile map
	Tile* map;

	//Size of the tile map
	int size, width, height;

	//Dictionary of tile frames
	std::unordered_map<int, Rectangle> dict_rect;

	Sprite* laser;

	//Tile sheet
	const Texture2D* img_tiles;
};