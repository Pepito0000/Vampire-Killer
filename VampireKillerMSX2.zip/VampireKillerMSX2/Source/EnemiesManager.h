#pragma once
#include "Enemies.h"
#include "Fire.h"
#include "Candle.h"
#include "Chest.h"

class EnemyManager
{
public:
	EnemyManager();
	~EnemyManager();

	AppStatus Initialise();
	void Add(const Point& pos, EnemyType type, const AABB& area, Look look = Look::RIGHT);
	AABB GetEnemyHitBox(const Point& pos, EnemyType type) const;
	void Update(const AABB& player_hitbox);
	void Draw() const;
	void DrawDebug() const;
	void Release();
	
	std::vector<Point> GetZombiePositions() const;
	std::vector<Point> GetCandlePositions() const; 
	std::vector<Enemy*>& GetEnemies() { return enemies; }
	std::vector<Point> GetFirePositions() const;
	std::vector<Point> GetChestPositions() const;

private:
	std::vector<Enemy*> enemies; 
};
