#pragma once
#include "Entity.h"
#include "TileMap.h"
#include "Object.h" 
#include "Enemies.h"
#include "EnemiesManager.h"
#include "StaticImage.h"
#include <vector>

//Representation model size: 32x32
#define PLAYER_FRAME_SIZE		        32

//Logical model size: 12x28
#define PLAYER_PHYSICAL_WIDTH	12
#define PLAYER_PHYSICAL_HEIGHT	28
#define ATTACK_WIDTH			24
#define ATTACK_HEIGHT			14

// HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT
#define HEALTH_BAR_WIDTH		4
#define HEALTH_BAR_HEIGHT		4

//Horizontal speed and vertical speed while falling down
#define PLAYER_SPEED_X			1

#define PLAYER_SPEED_Y			2

//Vertical speed while on a ladder
#define PLAYER_LADDER_SPEED		1

//Frame animation delay while on a ladder
#define ANIM_LADDER_DELAY		(2*ANIM_DELAY)

//When jumping, initial jump speed and maximum falling speed
#define PLAYER_JUMP_FORCE		3

//Frame delay for updating the jump velocity
#define PLAYER_JUMP_DELAY		4

//Player is levitating when abs(speed) <= this value
#define PLAYER_LEVITATING_SPEED	0

//Gravity affects jumping velocity when jump_delay is 0
#define GRAVITY_FORCE			1

//Logic states
enum class State { IDLE, WALKING, JUMPING, SNEAKING, FALLING, ATTACKING, DEAD, CLIMBING, HIT}; 

typedef struct 
{
	float Lifetime;
}Timer;

//Rendering states
enum class PlayerAnim {
	IDLE_LEFT, IDLE_RIGHT,
	WALKING_LEFT, WALKING_RIGHT,
	JUMPING_LEFT, JUMPING_RIGHT,
	LEVITATING_LEFT, LEVITATING_RIGHT,
	FALLING_LEFT, FALLING_RIGHT,
	FALLING_LEFT_NJ, FALLING_RIGHT_NJ,
	SNEAKING_LEFT, SNEAKING_RIGHT,
	ATTACKING_LEFT, ATTACKING_RIGHT,
	DEAD_LEFT, DEAD_RIGHT,
	CLIMBING_LEFT, CLIMBING_RIGHT, CLIMBING_PRE_TOP, CLIMBING_TOP,
	CLIMBING_UP_LEFT, CLIMBING_UP_RIGHT, CLIMBING_DOWN_LEFT, CLIMBING_DOWN_RIGHT, 
	SHOCK_LEFT, SHOCK_RIGHT, 
	TELEPORT_LEFT, TELEPORT_RIGHT, 
	NUM_ANIMATIONS 
};

class Player : public Entity
{
public:
	Player(const Point& p, State s, Look view);
	~Player();

	State GetState() const { return state; }   

	int GetBlueRingCount() const { return blueRingCount; } 
	AppStatus Initialise();
	void SetTileMap(TileMap* tilemap);
	
	void getDamage(Look DamageDirection); 

	void InitScore();
	void IncrScore(int n);
	int GetScore();
	int GetLives();
	int GetCorazones();

	void Update();
	void DrawDebug(const Color& col) const;
	void Release();

	void getHit(); 
	void ReactToEnemy(); 

	void Draw() const; 

	AABB GetAttackHitbox() const;  

	bool isDeadAnimationComplete = false;	// Para la win/lose condition
	
	// Inventario de items
	std::vector<ObjectType> items;  //
	const std::vector<ObjectType>& GetItems() const { return items; } 
	void DrawItem(ObjectType type, Vector2 pos); // Dibuja un �tem en una posici�n dada 
	Texture2D GetItemTexture(ObjectType type); // Obtiene la textura de un �tem dado su tipo 

	const int totalFramesAttack = 3;
	float currentFrameAttack = 0;
	float framesCounter = 0;
	float framesSpeed = 0.5f;

	void StartTimer(Timer* timer, float lifetime);
	void UpdateTimer(Timer* timer);
	bool TimerDone(Timer* timer);
	void StopTimer(Timer* timer);

	Timer attackTimer = { 0 };
	float attackLife = 0.3f; // Duration of the attack animation

	int getP();
	void RestarP();

	int GetPlayerPosX();
	int GetPlayerPosY();
	int GetLife() const;
	void CheckPosY(); 
	void IncreaseLife(int amount);
private:
	
	int blueRingCount = 0;	
	int deathFrameCounter = 0;
	StaticImage* healthBarSprite;	//la barra de vidica

	Sound soundArray[10];
	
	EnemyManager* enemyManager; 

	bool IsLookingRight() const;
	bool IsLookingLeft() const;

	//Player mechanics
	void MoveX();
	void MoveY();
	void MoveY_SNEAK();
	void LogicJumping();
	void Attack();
	float velocityY; // Para intentar arreglar el bug de caida + atacar (que se come el suelo)
	float posY;
	float gravity; 
	float groundLevel;
	bool hasAttackedInAir;
	void ApplyGravity();	//
	void UpdatePosition();	
	//Animation management
	void SetAnimation(int id);
	PlayerAnim GetAnimation();
	void Stop();
	void StartWalkingLeft();
	void StartWalkingRight();
	void StartFalling();
	void StartFalling_NJ();
	void StartJumping();
	void StartSneaking();
	void StopSneaking();
	void StartAttacking();
	void StopAttacking();
	void ChangeAnimRight();
	void ChangeAnimLeft();

	//Jump steps
	bool IsAscending() const;
	bool IsLevitating() const;
	bool IsDescending() const;

	//Ladder get in/out steps
	bool IsInFirstHalfTile() const;
	bool IsInSecondHalfTile() const;

	Timer damageTimer;   
	float damageDuration = 1.0f; 
	State state;
	Look look;
	int jump_delay;
	TileMap* map;
	int score;
	int lives, corazones;
	int attempts;

};