#pragma once
#include "Entity.h"

#define ENEMIES_FRAME_SIZE		   32
//Representation model size: 32x32
#define ZOMBIE_FRAME_SIZE		32
//Logical model size: 24x30
#define ZOMBIE_PHYSICAL_WIDTH	12
#define ZOMBIE_PHYSICAL_HEIGHT	28


#define CANDLE_FRAME_SIZE 16 

#define FIRE_PHYSICAL_WIDTH	16
#define FIRE_PHYSICAL_HEIGHT	32 

enum class EnemyType {ZOMBIE, AQUAMAN, CANDLE, FIRE, CHEST};     

class Enemy : public Entity
{
public:
	Enemy(const Point& p, int width, int height, int frame_width, int frame_height);
	virtual ~Enemy();
	void DrawVisibilityArea(const Color& col) const;
	virtual AppStatus Initialise(Look look, const AABB& area) = 0;
	virtual bool Update(const AABB& box) = 0;
	Point GetPos() const { return pos; }
	
protected:
	bool IsVisible(const AABB& hitbox); 
	Look look;
	AABB visibility_area;
};

