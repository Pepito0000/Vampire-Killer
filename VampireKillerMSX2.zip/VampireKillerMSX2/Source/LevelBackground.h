#pragma once

class CargarBackground
{
private:
	Texture2D backgroundImage, ui;
public:
	CargarBackground();
	void RenderBackground(int stage);
	void Release();
};