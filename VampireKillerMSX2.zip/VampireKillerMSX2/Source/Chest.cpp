#include "Chest.h" 
#include "Sprite.h"

Chest::Chest(const Point& p, int width, int height, int frame_width, int frame_height) :
    Enemy(p, width, height, frame_width, frame_height) {
    state = ChestState::IDLE; 
    current_step = 0; 
    current_frames = 0;
    dir = { 0, 0 };
}
Chest::~Chest() {}

AppStatus Chest::Initialise(Look look, const AABB& area) {
    const int n = CHEST_FRAME_SIZE;
    state = ChestState::IDLE;
    ResourceManager& data = ResourceManager::Instance();
    render = new Sprite(data.GetTexture(Resource::IMG_CHEST));
    if (render == nullptr) {
        LOG("Failed to allocate memory for chest sprite");
        return AppStatus::ERROR;
    }
    Sprite* sprite = dynamic_cast<Sprite*>(render);
    sprite->SetAnimationDelay((int)ChestAnim::IDLE, CHEST_ANIM_DELAY);
    sprite->AddKeyFrame((int)ChestAnim::IDLE, { 0, 0 , n, n });

    this->look = look;
    if (look == Look::LEFT) sprite->SetAnimation((int)ChestAnim::IDLE);
    else if (look == Look::RIGHT) sprite->SetAnimation((int)ChestAnim::IDLE);

    visibility_area = area;

    InitPattern();

    return AppStatus::OK;
}

void Chest::InitPattern() {
    const int n = CHEST_ANIM_DELAY * 2;
    pattern.clear();

    if (look == Look::LEFT) {
        pattern.push_back({ {CHEST_SPEED_X, 0}, n, (int)ChestAnim::IDLE });
    }
    else {
        pattern.push_back({ {-CHEST_SPEED_X, 0}, n, (int)ChestAnim::IDLE });
    }

    current_step = 0;
    current_frames = 0;
}

bool Chest::Update(const AABB& player_box) {
    Sprite* sprite = dynamic_cast<Sprite*>(render);
    if (sprite == nullptr) {
        LOG("Sprite is null in Update");
        return false;
    }

    int anim_id;

    sprite->Update();
    return false;

}

void Chest::UpdateLook(int anim_id) {
    ChestAnim anim = (ChestAnim)anim_id;
    look = (anim == ChestAnim::IDLE) ? Look::LEFT : Look::RIGHT; 
}