#pragma once
#include <raylib.h>
#include "Player.h"
#include "TileMap.h"
#include "Object.h"
#include "LevelBackground.h"
#include "EnemiesManager.h"
#include "Candle.h"
#include "Enemies.h"
#include "Text.h"
#include "Fire.h"
#include "EnemiesManager.h"
#include "Zombie.h"
#include "Object.h"

class Candle; 

enum class DebugMode { OFF, SPRITES_AND_HITBOXES, ONLY_HITBOXES, SIZE };

class Scene
{
public:
    bool exit;
    Scene();
    ~Scene();
    AppStatus Init();
    void Update();
    void UpdateBackground(int s);
    void Render();
    void Release();
    bool isFireDestroyed(const Vector2& pos, int level) const;
    int currentStage;
private:
    //Para comprovar que los objetos no se reinicien al cargar el nivel otra vez
    //Para no hacer reaparecer los fuegos iniciales
    std::vector<Vector2> destroyedFires;
    std::vector<Vector2> destroyedFirePositions;
    std::vector<int> destroyedFireLevels;
    std::vector<Vector2> destroyedCandlePositions;
    std::vector<int> destroyedCandleLevels;
    std::vector<Vector2> destroyedChestPositions;
    std::vector<int> destroyedChestLevels;

    //Para no hacer reaparecer items (final juego)
    std::vector<ObjectType> collectedObjects; 
    int firesDestroyed;
    int candleDestroyed;
    int candlesDestroyedInLevel4;
    int candlesDestroyedInLevel5;

    AppStatus LoadLevel(int stage);
    void GenerateZombies(); 
    void GenerateFire(); 
    void GenerateCandle();
    void GenerateChest(); 
    void CheckCollisions();
    void CheckEnemyCollisions();
    void ClearLevel();
    void RenderObjects() const;
    void RenderObjectsDebug(const Color& col) const;
    void RenderGUI() const;

    bool isCandleDestroyed(const Vector2& pos, int level) const; 

 
    bool isChestDestroyed(const Vector2& pos, int level) const;

    Player* player;
    TileMap* level;

    CargarBackground* background;

    std::vector<Object*> objects;
    Candle* candle; 
    Camera2D camera;
    DebugMode debug;
    EnemyManager* enemies; 
    Rectangle rc;
    bool fireGenerated = false; 
    bool chestGenerated = false;
    bool candleGenerated = false;
    Text* font;  
};