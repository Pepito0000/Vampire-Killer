#include "Fire.h" 
#include "Sprite.h"

Fire::Fire(const Point& p, int width, int height, int frame_width, int frame_height) :
    Enemy(p, width, height, frame_width, frame_height) {
    state = FireState::IDLE;  
    current_step = 0;
    current_frames = 0;
    dir = { 0, 0 };
}
Fire::~Fire() {}

AppStatus Fire::Initialise(Look look, const AABB& area) {
    const int n = FIRE_FRAME_SIZE;
    state = FireState::IDLE;
    ResourceManager& data = ResourceManager::Instance();
    render = new Sprite(data.GetTexture(Resource::IMG_FIRE)); 
    if (render == nullptr) {
        LOG("Failed to allocate memory for guepardo sprite");
        return AppStatus::ERROR;
    }

    Sprite* sprite = dynamic_cast<Sprite*>(render);
    sprite->SetNumberAnimations((int)FireAnim::NUM_ANIMATIONS);

    sprite->SetAnimationDelay((int)FireAnim::IDLE, 15);
    for (int i = 0; i < 2; ++i)
        sprite->AddKeyFrame((int)FireAnim::IDLE, { (float)i * n, 16 , n, n });


    this->look = look;
    if (look == Look::LEFT) sprite->SetAnimation((int)FireAnim::IDLE);
    else if (look == Look::RIGHT) sprite->SetAnimation((int)FireAnim::IDLE); 

    visibility_area = area;

    InitPattern();

    return AppStatus::OK;
}

void Fire::InitPattern() {
    const int n = FIRE_ANIM_DELAY * 2;
    pattern.clear();

    if (look == Look::LEFT) {
        pattern.push_back({ {FIRE_SPEED_X, 0}, n, (int)FireAnim::IDLE });
    }
    else {
        pattern.push_back({ {-FIRE_SPEED_X, 0}, n, (int)FireAnim::IDLE }); 
    }

    current_step = 0;
    current_frames = 0;
}

bool Fire::Update(const AABB& player_box) {
    Sprite* sprite = dynamic_cast<Sprite*>(render);
    if (sprite == nullptr) {
        LOG("Sprite is null in Update");
        return false;
    }

    int anim_id;

    sprite->Update();
    return false;

    }

void Fire::UpdateLook(int anim_id) {
    FireAnim anim = (FireAnim)anim_id; 
    look = (anim == FireAnim::IDLE) ? Look::LEFT : Look::RIGHT; 
}