
#include "Player.h"
#include "Sprite.h"
#include "TileMap.h"
#include "Globals.h"
#include <raymath.h>
#include "Enemies.h" 
#include "Game.h"

Player::Player(const Point& p, State s, Look view)  : gravity(0.5f), groundLevel(500.0f), hasAttackedInAir(false) ,
	Entity(p, PLAYER_PHYSICAL_WIDTH, PLAYER_PHYSICAL_HEIGHT, PLAYER_FRAME_SIZE, PLAYER_FRAME_SIZE)
{
	state = s;
	look = view;
	jump_delay = PLAYER_JUMP_DELAY;
	map = nullptr;
	score = 0;
	lives = 160;
	corazones = 3; 
	attempts = 2; 
	posY = GetPlayerPosY(); 

	healthBarSprite = nullptr;
}
Player::~Player()
{
	delete healthBarSprite; 
}
void Player::Draw() const {
	Entity::Draw();
	// Dibujar la barra de vida 
	if (healthBarSprite) { 
		for (int i = 0; i < lives / 10; ++i) {
			healthBarSprite->Draw(59 + i * (HEALTH_BAR_WIDTH), 15); 
		}
	}
}
AppStatus Player::Initialise()
{
	int i;
	const int n = PLAYER_FRAME_SIZE;

	soundArray[0] = LoadSound("Audio/Whip-Sound Effect.wav");

	ResourceManager& data = ResourceManager::Instance();
	if (data.LoadTexture(Resource::IMG_PLAYER, "images/Sprites/PersonajePrincipal.png") != AppStatus::OK)
	{
		return AppStatus::ERROR;
	}

	render = new Sprite(data.GetTexture(Resource::IMG_PLAYER));
	if (render == nullptr)
	{
		LOG("Failed to allocate memory for player sprite");
		return AppStatus::ERROR;
	}

	if (data.LoadTexture(Resource::IMG_UI, "images/Sprites/player.png") != AppStatus::OK) { 
		LOG("Failed to load health sprite texture");
		return AppStatus::ERROR;
	}
	const Texture2D* healthTexture = data.GetTexture(Resource::IMG_UI);
	if (healthTexture) {
		healthBarSprite = new StaticImage(healthTexture, { 0, 0, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT });
	}
	else {
		LOG("Failed to get health sprite texture");
		return AppStatus::ERROR;
	}

	Sprite* sprite = dynamic_cast<Sprite*>(render);
	sprite->SetNumberAnimations((int)PlayerAnim::NUM_ANIMATIONS);

	sprite->SetAnimationDelay((int)PlayerAnim::IDLE_RIGHT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::IDLE_RIGHT, { 0, 0, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::IDLE_LEFT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::IDLE_LEFT, { 0, 0, -n, n });

	//Muerto (HAY UN BUG)
	sprite->SetAnimationDelay((int)PlayerAnim::DEAD_RIGHT, ANIM_DELAY);
	for (i = 8; i < 10; ++i)
		sprite->AddKeyFrame((int)PlayerAnim::DEAD_RIGHT, { (float)i * n, 0 * n, n, n });

	sprite->SetAnimationDelay((int)PlayerAnim::DEAD_LEFT, ANIM_DELAY);
	for (i = 8; i < 10; ++i) {
		sprite->AddKeyFrame((int)PlayerAnim::DEAD_LEFT, { (float)i * n, 0 * n, -n, n });
	}
	//
	sprite->SetAnimationDelay((int)PlayerAnim::FALLING_RIGHT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::FALLING_RIGHT, { 3 * n, 0 * n, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::FALLING_LEFT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::FALLING_LEFT, { 3 * n, 0 * n, -n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::FALLING_RIGHT_NJ, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::FALLING_RIGHT_NJ, { 0 * n, 0 * n, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::FALLING_LEFT_NJ, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::FALLING_LEFT_NJ, { 0 * n, 0 * n, -n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::SNEAKING_RIGHT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::SNEAKING_RIGHT, { 3 * n, 0 * n, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::SNEAKING_LEFT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::SNEAKING_LEFT, { 3 * n, 0 * n, -n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::WALKING_RIGHT, ANIM_DELAY);
	for (i = 0; i < 3; ++i)
		sprite->AddKeyFrame((int)PlayerAnim::WALKING_RIGHT, { (float)i * n, 0 * n, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::WALKING_LEFT, ANIM_DELAY);
	for (i = 0; i < 3; ++i)
		sprite->AddKeyFrame((int)PlayerAnim::WALKING_LEFT, { (float)i * n, 0 * n, -n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::CLIMBING_LEFT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::CLIMBING_LEFT, {}); 

	sprite->SetAnimationDelay((int)PlayerAnim::JUMPING_RIGHT, ANIM_DELAY); 
	sprite->AddKeyFrame((int)PlayerAnim::JUMPING_RIGHT, { 0, 1 * n, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::JUMPING_LEFT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::JUMPING_LEFT, { 0, 1 * n, -n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::LEVITATING_RIGHT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::LEVITATING_RIGHT, { n, 0 * n, n, n });
	sprite->SetAnimationDelay((int)PlayerAnim::LEVITATING_LEFT, ANIM_DELAY);
	sprite->AddKeyFrame((int)PlayerAnim::LEVITATING_LEFT, { n, 0 * n, -n, n });

	//Atacar
	sprite->SetAnimationDelay((int)PlayerAnim::ATTACKING_RIGHT, 6);
	for (i = 0; i < 3; ++i)
		sprite->AddKeyFrame((int)PlayerAnim::ATTACKING_RIGHT, { (float)i * (2 * n), 4 * n, 2 * n, n });

	sprite->SetAnimationDelay((int)PlayerAnim::ATTACKING_LEFT, 6);
	for (i = 0; i < 3; ++i)
		sprite->AddKeyFrame((int)PlayerAnim::ATTACKING_LEFT, { (float)i * (2 * n) - n, 4 * n, -2 * n, n });


	sprite->SetAnimation((int)PlayerAnim::IDLE_RIGHT);

	return AppStatus::OK;
}

void Player::CheckPosY() {
	if (pos.y > WINDOW_HEIGHT - TILE_SIZE * 3 - 5) 
	{
		pos.y = (WINDOW_HEIGHT - TILE_SIZE * 3 - 5);
	}
	else if (pos.y < WINDOW_HEIGHT - LEVEL_HEIGHT * TILE_SIZE - TILE_SIZE) 
	{
		pos.y = WINDOW_HEIGHT - LEVEL_HEIGHT * TILE_SIZE - TILE_SIZE;
	}
}
void Player::IncreaseLife(int amount) {
	corazones += amount;
}
int Player::GetLife() const {
	return lives;
}

void Player::InitScore()
{
	score = 0;
}
void Player::IncrScore(int n)
{
	score += n;
}
int Player::GetScore()
{
	return score;
}
void Player::SetTileMap(TileMap* tilemap)
{
	map = tilemap;
}
bool Player::IsLookingRight() const
{
	return look == Look::RIGHT;
}
bool Player::IsLookingLeft() const
{
	return look == Look::LEFT;
}
bool Player::IsAscending() const
{
	return dir.y < -PLAYER_LEVITATING_SPEED;
}
bool Player::IsLevitating() const
{
	return abs(dir.y) <= PLAYER_LEVITATING_SPEED;
}
bool Player::IsDescending() const
{
	return dir.y > PLAYER_LEVITATING_SPEED;
}
bool Player::IsInFirstHalfTile() const
{
	return pos.y % TILE_SIZE < TILE_SIZE / 2;
}
bool Player::IsInSecondHalfTile() const
{
	return pos.y % TILE_SIZE >= TILE_SIZE / 2;
}
void Player::SetAnimation(int id)
{
	Sprite* sprite = dynamic_cast<Sprite*>(render);
	sprite->SetAnimation(id);
}
PlayerAnim Player::GetAnimation()
{
	Sprite* sprite = dynamic_cast<Sprite*>(render);
	return (PlayerAnim)sprite->GetAnimation();
}
void Player::Stop()
{
	dir = { 0,0 };
	state = State::IDLE;
	if (IsLookingRight())	SetAnimation((int)PlayerAnim::IDLE_RIGHT);
	else					SetAnimation((int)PlayerAnim::IDLE_LEFT);
}
void Player::StartWalkingLeft()
{
	state = State::WALKING;
	look = Look::LEFT;
	SetAnimation((int)PlayerAnim::WALKING_LEFT);
}
void Player::StartWalkingRight()
{
	state = State::WALKING;
	look = Look::RIGHT;
	SetAnimation((int)PlayerAnim::WALKING_RIGHT);
}
void Player::StartFalling()
{
	dir.y = PLAYER_SPEED_Y;
	state = State::FALLING;
	if (IsLookingRight())	SetAnimation((int)PlayerAnim::FALLING_RIGHT);
	else					SetAnimation((int)PlayerAnim::FALLING_LEFT);
}
void Player::StartFalling_NJ()
{
	dir.y = PLAYER_SPEED_Y;
	state = State::FALLING;
	if (IsLookingRight())	SetAnimation((int)PlayerAnim::FALLING_RIGHT_NJ);
	else					SetAnimation((int)PlayerAnim::FALLING_LEFT_NJ);
}
void Player::StartJumping()
{
	dir.y = -PLAYER_JUMP_FORCE;
	state = State::JUMPING;
	if (IsLookingRight())	SetAnimation((int)PlayerAnim::JUMPING_RIGHT);
	else					SetAnimation((int)PlayerAnim::JUMPING_LEFT);
	jump_delay = PLAYER_JUMP_DELAY;
}
void Player::StartSneaking()
{
	state = State::SNEAKING;
	if (IsLookingRight())	SetAnimation((int)PlayerAnim::SNEAKING_RIGHT);
	else					SetAnimation((int)PlayerAnim::SNEAKING_LEFT);
}
void Player::StopSneaking()
{
	state = State::IDLE;
	if (IsLookingRight())   SetAnimation((int)PlayerAnim::IDLE_RIGHT);
	else					SetAnimation((int)PlayerAnim::IDLE_LEFT);

}

void Player::getDamage(Look damageDirection)
{
	if (!IsBlinking()) {
		lives -= 10;
		if (lives <= 0) {
			state = State::DEAD;
			isDeadAnimationComplete = false; // Reiniciar la variable cuando el jugador muere
			deathFrameCounter = 0; // Reiniciar el contador de cuadros
			RestarP();
			if (getP() == 0) {
				// Aqu� reiniciamos al jugador
				pos = { 0, LEVEL_HEIGHT * TILE_SIZE - TILE_SIZE }; // Reiniciar la posici�n al inicio del nivel
				lives = 160; // Reiniciar las vidas
				state = State::IDLE; // Reiniciar el estado
				look = Look::RIGHT; // Reiniciar la direcci�n
			}
		}
		else {
			StartBlinking(damageDuration, damageDirection);
			state = State::HIT;
			dir.y = -PLAYER_JUMP_FORCE;
		}
	}
}

int Player::getP() {
	return attempts;   
}
void Player::RestarP() {
	int p = getP();
	p - 1;
}
void Player::StartAttacking() {
	// Establecer el estado a ATTACKING solo si no est� actualmente atacando
	{
		state = State::ATTACKING;
		PlaySound(soundArray[0]);
		// Establecer la animaci�n de ataque seg�n la direcci�n del jugador
		if (IsLookingRight()) {
			SetAnimation((int)PlayerAnim::ATTACKING_RIGHT);
		}
		else {
			SetAnimation((int)PlayerAnim::ATTACKING_LEFT);
		}
		StartTimer(&attackTimer, attackLife);
	}
}
void Player::StopAttacking() {
	StopTimer(&attackTimer);
	state = State::IDLE;
	if (IsLookingRight()) {
		SetAnimation((int)PlayerAnim::IDLE_RIGHT);
	}
	else {
		SetAnimation((int)PlayerAnim::IDLE_LEFT);
	}

}
void Player::ChangeAnimRight()
{
	look = Look::RIGHT;
	switch (state)
	{
	case State::IDLE:	 SetAnimation((int)PlayerAnim::IDLE_RIGHT);    break;
	case State::WALKING: SetAnimation((int)PlayerAnim::WALKING_RIGHT); break;
	case State::JUMPING: SetAnimation((int)PlayerAnim::JUMPING_RIGHT); break;
	case State::SNEAKING: SetAnimation((int)PlayerAnim::SNEAKING_RIGHT); break;
	case State::FALLING: SetAnimation((int)PlayerAnim::FALLING_RIGHT); break;
	case State::ATTACKING: SetAnimation((int)PlayerAnim::ATTACKING_RIGHT); break;
	case State::DEAD: SetAnimation((int)PlayerAnim::DEAD_RIGHT); break;
	}
}
void Player::ChangeAnimLeft()
{
	look = Look::LEFT;
	switch (state)
	{
	case State::IDLE:	 SetAnimation((int)PlayerAnim::IDLE_LEFT);    break;
	case State::WALKING: SetAnimation((int)PlayerAnim::WALKING_LEFT); break;
	case State::JUMPING: SetAnimation((int)PlayerAnim::JUMPING_LEFT); break;
	case State::SNEAKING: SetAnimation((int)PlayerAnim::SNEAKING_LEFT); break;
	case State::FALLING: SetAnimation((int)PlayerAnim::FALLING_LEFT); break;
	case State::ATTACKING: SetAnimation((int)PlayerAnim::ATTACKING_LEFT); break;
	case State::DEAD: SetAnimation((int)PlayerAnim::DEAD_LEFT); break;
	}
}
void Player::Update()
{
	if (state != State::HIT && state != State::DEAD) {
		MoveX();
		MoveY();
		MoveY_SNEAK();
		Attack();
	}
	else if (state == State::DEAD) {
		if (!isDeadAnimationComplete) {
			// Incrementa el frame de la animaci�n de DEAD
			Sprite* sprite = dynamic_cast<Sprite*>(render);
			sprite->Update();

			// Verifica si la animaci�n de DEAD ha llegado al segundo cuadro
			if (sprite->GetCurrentFrame() >= 1) {
				isDeadAnimationComplete = true;
				// Mantiene el segundo cuadro de la animaci�n de DEAD
				sprite->SetCurrentFrame(1);
			}
		}
	}
	else {
		if (damageDirection == Look::LEFT) {
			dir.x = PLAYER_SPEED_X;
		}
		else {
			dir.x = -PLAYER_SPEED_X;
		}
		LogicJumping();
	}

	Entity::Update();

	if (state != State::DEAD || !isDeadAnimationComplete) {
		Sprite* sprite = dynamic_cast<Sprite*>(render);
		sprite->Update();
	}
}
int Player::GetCorazones() {
	return corazones; 
}
void Player::MoveX()
{
	AABB hitbox;
	int previousX = pos.x;

	if (state != State::ATTACKING)
	{
		// Movimiento hacia la izquierda
		if (IsKeyDown(KEY_LEFT) && !IsKeyDown(KEY_RIGHT) && state != State::SNEAKING)
		{
			pos.x -= PLAYER_SPEED_X;

			if (state == State::IDLE)
			{
				StartWalkingLeft();
			}
			else if (IsLookingRight())
			{
				ChangeAnimLeft();
			}

			hitbox = GetHitbox();
			if (map->TestCollisionWallLeft(hitbox))
			{
				pos.x = previousX;
				if (state == State::WALKING)
				{
					Stop();
				}
			}
		}
		// Movimiento hacia la derecha
		else if (IsKeyDown(KEY_RIGHT) && state != State::SNEAKING)
		{
			pos.x += PLAYER_SPEED_X;

			if (state == State::IDLE)
			{
				StartWalkingRight();
			}
			else if (IsLookingLeft())
			{
				ChangeAnimRight();
			}

			hitbox = GetHitbox();
			if (map->TestCollisionWallRight(hitbox))
			{
				pos.x = previousX;
				if (state == State::WALKING)
				{
					Stop();
				}
			}
		}
		// Detener movimiento
		else
		{
			if (state == State::WALKING)
			{
				Stop();
			}
		}
	}

}

void Player::MoveY()
{
	AABB box;

	if (state == State::ATTACKING) {
		return; 
	}

	if (state == State::JUMPING)
	{
		LogicJumping();
	}

	else //idle, walking, falling
	{
		pos.y += PLAYER_SPEED_Y;
		box = GetHitbox();
		if (map->TestCollisionGround(box, &pos.y))
		{
			if (state == State::FALLING) Stop();


			else if (IsKeyPressed(KEY_UP))
			{
				StartJumping();
			}
		}
		else
		{
			if (state != State::FALLING) StartFalling_NJ();
		}
	}
}
AABB Player::GetAttackHitbox() const {
	if (state == State::ATTACKING) {
		Point attackPos = pos;

		// Ajustar la posici�n de ataque seg�n la direcci�n en que se mira
		if (IsLookingRight()) {
			attackPos.x += width;
		}
		else {
			attackPos.x -= (2 * PLAYER_FRAME_SIZE);
		}

		// Ajustar la posici�n vertical del ataque
		attackPos.y -= (height - ATTACK_HEIGHT) / 2;

		// Devolver el AABB para el ataque
		return AABB(attackPos, 2 * PLAYER_FRAME_SIZE, ATTACK_HEIGHT);
	}

	// Devolver un AABB vac�o si no est� atacando
	return AABB();
}
void Player::MoveY_SNEAK()
{
	if (state == State::ATTACKING) {
		return;
	}

	if (IsKeyDown(KEY_DOWN))
	{
		if (state != State::SNEAKING)
			StartSneaking();

	}
	else
	{
		if (state == State::SNEAKING)
			StopSneaking();

	}
}

void Player::Attack()
{
	if (IsKeyDown(KEY_SPACE) && state != State::ATTACKING && state != State::SNEAKING && state != State::DEAD)
	{
		if (posY >= GetPlayerPosY())
		{
			StartAttacking();
		}
		else if (posY < GetPlayerPosY() && !hasAttackedInAir)
		{
			StartAttacking();
			hasAttackedInAir = true;
		}
	}
	UpdateTimer(&attackTimer);
	if (state == State::ATTACKING && TimerDone(&attackTimer))
	{
		StopAttacking();
	}
}

void Player::ApplyGravity()
{
	// Aplica la gravedad si el jugador no est� en el suelo
	if (posY < GetPlayerPosY())
	{
		velocityY += gravity;
	}
	else
	{
		velocityY = 0;
	}
}

void Player::UpdatePosition()
{
	posY += velocityY;

	// Verificaci�n para asegurarse de que el jugador no atraviese el suelo
	if (posY > GetPlayerPosY())
	{
		posY = GetPlayerPosY();
		velocityY = 0;
		hasAttackedInAir = false; // Reinicia la bandera cuando el jugador vuelve al suelo
	}
}

void Player::LogicJumping()
{
	AABB box, prev_box;
	int prev_y;

	jump_delay--;
	if (jump_delay == 0)
	{
		prev_y = pos.y;
		prev_box = GetHitbox();

		pos.y += dir.y;
		dir.y += GRAVITY_FORCE;
		jump_delay = PLAYER_JUMP_DELAY;

		//Is the jump finished?
		if (dir.y > PLAYER_JUMP_FORCE)
		{
			dir.y = PLAYER_SPEED_Y;
			StartFalling();
		}
		else
		{
			//Jumping is represented with 3 different states
			if (IsAscending())
			{
				if (IsLookingRight())	SetAnimation((int)PlayerAnim::JUMPING_RIGHT);
				else					SetAnimation((int)PlayerAnim::JUMPING_LEFT);
			}
			else if (IsLevitating())
			{
				if (IsLookingRight())	SetAnimation((int)PlayerAnim::LEVITATING_RIGHT);
				else					SetAnimation((int)PlayerAnim::LEVITATING_LEFT);
			}
			else if (IsDescending())
			{
				if (IsLookingRight())	SetAnimation((int)PlayerAnim::FALLING_RIGHT);
				else					SetAnimation((int)PlayerAnim::FALLING_LEFT);
			}
		}
		//We check ground collision when jumping down
		if (dir.y >= 0)
		{
			box = GetHitbox();

			if (!map->TestCollisionGround(prev_box, &prev_y) &&
				map->TestCollisionGround(box, &pos.y))
			{
				Stop();
			}
		}
	}
}
//Dibujar items
void Player::DrawItem(ObjectType type, Vector2 pos)
{
	Texture2D texture = GetItemTexture(type);
	DrawTexture(texture, pos.x, pos.y, WHITE);
}
Texture2D Player::GetItemTexture(ObjectType type)
{
	switch (type)
	{
	case ObjectType::GOLDEN_KEY:
		return LoadTexture("images/Items/GoldenKey.png"); 
	case ObjectType::SILVER_KEY:
		return LoadTexture("images/Items/SilverKey.png"); 
	case ObjectType::BLUE_RING: 
		return LoadTexture("images/Items/BlueRing.png");
	default:
		return LoadTexture("path/to/default_item.png");
	}
}
void Player::DrawDebug(const Color& col) const
{
	Entity::DrawHitbox(pos.x, pos.y, width, height, col);

	DrawText(TextFormat("Position: (%d,%d)\nSize: %dx%d\nFrame: %dx%d", pos.x, pos.y, width, height, frame_width, frame_height), 18 * 16, 0, 8, LIGHTGRAY);
	DrawPixel(pos.x, pos.y, WHITE);
}
void Player::Release()
{
	ResourceManager& data = ResourceManager::Instance();
	data.ReleaseTexture(Resource::IMG_PLAYER);

	render->Release();
}
void Player::StartTimer(Timer* timer, float lifetime) 
{
	if (timer != NULL)
		timer->Lifetime = lifetime;
}
void Player::UpdateTimer(Timer* timer)
{
	if (timer != NULL && timer->Lifetime > 0)
		timer->Lifetime -= GetFrameTime();
}
bool Player::TimerDone(Timer* timer) 
{
	if (timer != NULL)
		return timer->Lifetime <= 0;

	return false;
}
void Player::StopTimer(Timer* timer) 
{
	if (timer != NULL)
		timer->Lifetime = 0;
}
int Player::GetLives()
{
	return this->lives;
}
int Player::GetPlayerPosX()
{
	return pos.x;
}

int Player::GetPlayerPosY()
{
	return pos.y;
}