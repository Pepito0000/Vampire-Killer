#pragma once
#include "Enemies.h"
#include "TileMap.h"
//Igual implementado que ZOMBIE

#define CANDLE_SPEED_X       2
#define CANDLE_SPEED_Y       2
#define CANDLE_JUMP_FORCE    3
#define CANDLE_ANIM_DELAY    (3*ANIM_DELAY)
#define CANDLE_FRAME_SIZE    16

enum class CandleState { IDLE };
enum class CandleAnim {
    IDLE,
    NUM_ANIMATIONS
};

struct CandleStep {
    Point speed;
    int frames;
    int anim;
};

class Candle : public Enemy {
public:
    Candle(const Point& p, int width, int height, int frame_width, int frame_height);
    ~Candle();

    AppStatus Initialise(Look look, const AABB& area) override;
    bool Update(const AABB& box) override;


private:
    void InitPattern();
    void UpdateLook(int anim_id);

    CandleState state;
    int current_step; // No hace falta. la vela esta quieta, pero no funciona sin esto�
    int current_frames;
    std::vector<CandleStep> pattern;

    float base_y;
    Point dir;
    TileMap* map;
};

