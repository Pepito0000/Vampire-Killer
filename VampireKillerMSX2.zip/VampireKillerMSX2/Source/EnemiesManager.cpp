#include "EnemiesManager.h"
#include "Zombie.h"

EnemyManager::EnemyManager()
{

}
EnemyManager::~EnemyManager()
{
	Release();
}
AppStatus EnemyManager::Initialise()
{
	ResourceManager& data = ResourceManager::Instance();
	if (data.LoadTexture(Resource::IMG_ENEMIES, "images/sprites/Enemies.png") != AppStatus::OK)
	{
		LOG("Failed to load enemies sprite texture");
		return AppStatus::ERROR;
	}
	if (data.LoadTexture(Resource::IMG_CANDLE, "images/Animaciones/Candle.png") != AppStatus::OK)
	{
		LOG("Failed to load enemies sprite texture");
		return AppStatus::ERROR;
	}
	if (data.LoadTexture(Resource::IMG_FIRE, "images/Animaciones/Fire.png") != AppStatus::OK)
	{
		LOG("Failed to load enemies sprite texture");
		return AppStatus::ERROR;
	}
	if (data.LoadTexture(Resource::IMG_CHEST, "images/Animaciones/Chest.png") != AppStatus::OK) 
	{
		LOG("Failed to load enemies sprite texture");
		return AppStatus::ERROR;
	}
	return AppStatus::OK;
}

void EnemyManager::Add(const Point& pos, EnemyType type, const AABB& area, Look look)
{
	Enemy* enemy;

	if (type == EnemyType::ZOMBIE)
	{
		enemy = new Zombie(pos, ZOMBIE_PHYSICAL_WIDTH, ZOMBIE_PHYSICAL_HEIGHT, ZOMBIE_FRAME_SIZE, ZOMBIE_FRAME_SIZE); //Slime.h
	}
	else if (type == EnemyType::FIRE) {
		enemy = new Fire(pos, FIRE_PHYSICAL_WIDTH, FIRE_PHYSICAL_HEIGHT, FIRE_FRAME_SIZE, FIRE_PHYSICAL_HEIGHT); 
	}
	else if (type == EnemyType::CANDLE) { 
		enemy = new Candle(pos, FIRE_PHYSICAL_WIDTH, FIRE_PHYSICAL_HEIGHT, FIRE_FRAME_SIZE, FIRE_PHYSICAL_HEIGHT);
	}
	else if (type == EnemyType::CHEST) {
		enemy = new Chest(pos, FIRE_PHYSICAL_WIDTH, FIRE_PHYSICAL_HEIGHT, FIRE_FRAME_SIZE, FIRE_PHYSICAL_HEIGHT);
	}
	//else if (type == EnemyType::AQUAMAN)
	//{
	//	enemy = new Aquaman(pos, AQUAMAN_PHYSICAL_WIDTH, AQUAMAN_PHYSICAL_HEIGHT, AQUAMAN_FRAME_SIZE, AQUAMAN_FRAME_SIZE); //Turret.h
	//}
	else
	{
		LOG("Internal error: trying to add a new enemy with invalid type");
		return;
	}

	enemy->Initialise(look, area);
	enemies.push_back(enemy);
}
AABB EnemyManager::GetEnemyHitBox(const Point& pos, EnemyType type) const
{
	int width, height;
	if (type == EnemyType::ZOMBIE)
	{
		width = ZOMBIE_PHYSICAL_WIDTH; 
		height = ZOMBIE_PHYSICAL_HEIGHT; 
	}
	else if (type == EnemyType::FIRE)
	{
		width = FIRE_PHYSICAL_WIDTH;
		height = FIRE_PHYSICAL_HEIGHT;
	}
	else if (type == EnemyType::CANDLE)
	{
		width = FIRE_PHYSICAL_WIDTH;
		height = FIRE_PHYSICAL_HEIGHT;
	}
	else if (type == EnemyType::CHEST) 
	{
		width = FIRE_PHYSICAL_WIDTH;
		height = FIRE_PHYSICAL_HEIGHT;
	}
	else
	{
		LOG("Internal error while computing hitbox for an invalid enemy type");
		return {};
	}
	Point p(pos.x, pos.y - (height - 1));
	AABB hitbox(p, width, height);
	return hitbox;
}
void EnemyManager::Update(const AABB& player_hitbox)
{
	for (Enemy* enemy : enemies)
	{
		enemy->Update(player_hitbox); // Llama a la funci�n Update de cada enemigo
	}
}
void EnemyManager::Draw() const
{
	for (const Enemy* enemy : enemies)
		enemy->Draw();
}
void EnemyManager::DrawDebug() const
{
	for (const Enemy* enemy : enemies)
	{
		enemy->DrawVisibilityArea(DARKGRAY);
		enemy->DrawHitbox(RED);
	}
}
std::vector<Point> EnemyManager::GetZombiePositions() const
{
	std::vector<Point> positions;

	// Recorre todos los enemigos
	for (const Enemy* enemy : enemies)
	{
		// Si el enemigo es un zombie, a�ade su posici�n a la lista
		if (dynamic_cast<const Zombie*>(enemy))
		{
			positions.push_back(enemy->GetPos());
		}
	}

	return positions;
}
std::vector<Point> EnemyManager::GetChestPositions() const
{
	std::vector<Point> positions;

	// Recorre todos los enemigos
	for (const Enemy* enemy : enemies)
	{
		// Si el enemigo es un zombie, a�ade su posici�n a la lista
		if (dynamic_cast<const Chest*>(enemy)) 
		{
			positions.push_back(enemy->GetPos());
		}
	}

	return positions;
}
std::vector<Point> EnemyManager::GetFirePositions() const {
	std::vector<Point> positions;

	// Recorre todos los enemigos
	for (const Enemy* enemy : enemies) {
		// Si el enemigo es un murcielago, a�ade su posici�n a la lista
		if (dynamic_cast<const Fire*>(enemy)) { 
			positions.push_back(enemy->GetPos());
		}
	}

	return positions;
}
std::vector<Point> EnemyManager::GetCandlePositions() const {
	std::vector<Point> positions;

	// Recorre todos los enemigos
	for (const Enemy* enemy : enemies) {
		// Si el enemigo es un murcielago, a�ade su posici�n a la lista
		if (dynamic_cast<const Candle*>(enemy)) { 
			positions.push_back(enemy->GetPos());
		}
	}

	return positions;
}
void EnemyManager::Release()
{
	for (Enemy* enemy : enemies)
		delete enemy;
	enemies.clear();
}