#pragma once
#include "Globals.h"
#include "Scene.h"

enum class GameState { MAIN_MENU, PLAYING, INTRO, SETTINGS, CREDITS, RESET }; 

class Game
{
public:
    Game();
    ~Game();

    AppStatus Initialise(float scale);
    AppStatus Update();
    void Render();
    void Cleanup();
    void ResetAnimations();
    void ResetCredits();
    void SetState(GameState newState);
    //Personaje 
    Vector2 posicionPersonaje = { WINDOW_WIDTH - 30, 95 }; 
    const int FramesPersonajeFrontal = 3;
    const int FramesCharacterEspaldas = 1;
    float currentFramePersonajeFrontal = 0; 
    float currentFramePersonajeEspaldas = 5; 
    bool personajeEstaFrontal = true;
    bool personajeQuieto = false;   
    Texture2D personajeFrontal; 
    Texture2D personajeEspaldas; 

    //Nube
    Vector2 posicionNube = { WINDOW_WIDTH - 52, 100 }; 
    Texture2D nube;  

    //Murcia
    Vector2 posMurcielago = { WINDOW_WIDTH / 3 + 30, 70 }; 
    Vector2 pos2Murcielago = { WINDOW_WIDTH / 3 - 110, 120 }; 
    const int totalFramesMurcielago = 2;
    const int totalFramesMurcielago2 = 2;
    float currentFrameMurcielago = 0;
    float currentFrameMurcielago2 = 0;
    bool animacionMurcielagoPlayed = false;
    bool animationbat2Played = false;
    Texture2D murcielago;
    Texture2D murcielago2;

    //Cosas frames intro y mas
    const int FramesIntro = 3;
    const int FramesAnimacion2 = 3;
    float currentFrameIntro = 0;
    float currentFrameAnimacion2 = 0;
    float contadorFrames = 0;
    float contadorFrames2 = 0;
    float velFrames2 = 1;
    float velFrames = 1;
    bool introPlayed = false;
    bool animation2Played = false;
    bool music1Played = false;
    bool music2Played = false;
    bool music3Played = false;
    Texture2D background;
    Texture2D intro;
    Texture2D castillo;

   //Creditos
    bool creditsFinished = false;
    float creditPositionY = WINDOW_HEIGHT;
    Texture2D creditos_finales; 

private:
    AppStatus BeginPlay();
    void FinishPlay();

    AppStatus LoadResources();
    void UnloadResources();

    GameState state;
    Scene* scene;
    const Texture2D* img_menu;

    //To work with original game units and then scale the result
    RenderTexture2D target;
    Rectangle src, dst;

    Sound soundArray[10];
    Music musicArray[10];
};