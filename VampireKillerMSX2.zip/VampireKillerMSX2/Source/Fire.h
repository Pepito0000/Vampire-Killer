#pragma once
#include "Enemies.h"
#include "TileMap.h"
//Igual implementado que ZOMBIE

#define FIRE_SPEED_X       2
#define FIRE_SPEED_Y       2
#define FIRE_JUMP_FORCE    3
#define FIRE_ANIM_DELAY    (3*ANIM_DELAY)
#define FIRE_FRAME_SIZE    16

enum class FireState {IDLE};
enum class FireAnim {
    IDLE,
    NUM_ANIMATIONS
};

struct FireStep {
    Point speed;
    int frames;
    int anim;
};

class Fire : public Enemy { 
public:
    Fire(const Point& p, int width, int height, int frame_width, int frame_height);
    ~Fire();

    AppStatus Initialise(Look look, const AABB& area) override;
    bool Update(const AABB& box) override;


private:
    void InitPattern();
    void UpdateLook(int anim_id);

    FireState state;
    int current_step;
    int current_frames;
    std::vector<FireStep> pattern;

    float base_y;

    Point dir;

    TileMap* map;
};